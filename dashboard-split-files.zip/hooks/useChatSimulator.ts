'use client';

import { useEffect, useRef, useState } from 'react';
import { ChatMessage, Lead } from '@/types/dashboard';

/** State + handlers for the "Web & Social Simulator" (chat) tab. */
export function useChatSimulator() {
  const [channel, setChannel] = useState<string>('whatsapp');
  const [sessionId, setSessionId] = useState<string>('');
  const [inputMsg, setInputMsg] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentLead, setCurrentLead] = useState<Lead>(null);
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const newSession = `${channel}-web-${Math.random().toString(36).slice(2, 8)}`;
    setSessionId(newSession);
  }, [channel]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  async function handleSendChat(textToSend?: string) {
    const text = (textToSend || inputMsg).trim();
    if (!text || isTyping) return;
    setInputMsg('');
    const newMsgs = [...messages, { sender: 'customer' as const, text }];
    setMessages(newMsgs);
    setIsTyping(true);
    try {
      const res = await fetch('/api/test/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId, text, channel }),
      });
      const data = await res.json();
      if (data.skipped) {
        setMessages((prev) => [...prev, { sender: 'system', text: '(This lead is marked do-not-contact — no AI reply sent.)' }]);
      } else if (data.reply) {
        setMessages((prev) => [...prev, { sender: 'ai', text: data.reply }]);
      } else if (data.error) {
        setMessages((prev) => [...prev, { sender: 'system', text: `Error: ${data.error}` }]);
      }
      if (data.lead) setCurrentLead(data.lead);
    } catch {
      setMessages((prev) => [...prev, { sender: 'system', text: 'Network error communicating with Realty AI server.' }]);
    } finally {
      setIsTyping(false);
    }
  }

  return {
    channel,
    setChannel,
    sessionId,
    inputMsg,
    setInputMsg,
    messages,
    currentLead,
    isTyping,
    chatBottomRef,
    handleSendChat,
  };
}
