import React from 'react';
import { RefreshCw } from 'lucide-react';
import { iconBtnStyle, panelStyle, statusBadgeStyle, tableStyle, tempBadgeStyle } from '@/lib/dashboard/styles';
import { Lead } from '@/types/dashboard';

export function LeadsTab({
  leads,
  loadingLeads,
  fetchLeads,
}: {
  leads: Lead[];
  loadingLeads: boolean;
  fetchLeads: () => void;
}) {
  return (
    <div style={panelStyle}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <h2 style={{ fontSize: '18px', fontWeight: '600' }}>Leads Directory</h2>
        <button onClick={fetchLeads} style={iconBtnStyle}><RefreshCw size={14} /> Refresh</button>
      </div>
      {loadingLeads ? <p style={{ color: '#9ca3af' }}>Loading leads...</p> : (
        <table style={tableStyle}>
          <thead>
            <tr>
              <th>Name / ID</th><th>Channel</th><th>Intent</th><th>Budget</th>
              <th>Locations</th><th>Status</th><th>Temp</th><th>Score</th><th>Last Active</th>
            </tr>
          </thead>
          <tbody>
            {leads.map((l) => (
              <tr key={l.id}>
                <td>{l.name || l.external_user_id}</td>
                <td style={{ textTransform: 'capitalize' }}>{l.channel}</td>
                <td>{l.intent || '—'}</td>
                <td>{l.budget_max ? `₹${(l.budget_max / 100000).toFixed(1)}L` : '—'}</td>
                <td>{(l.preferred_locations || []).join(', ') || '—'}</td>
                <td><span style={statusBadgeStyle(l.status)}>{l.status}</span></td>
                <td><span style={tempBadgeStyle(l.temperature)}>{l.temperature}</span></td>
                <td><strong>{l.lead_score ?? 0}</strong></td>
                <td>{new Date(l.updated_at).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
