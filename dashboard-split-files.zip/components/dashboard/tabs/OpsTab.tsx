import React from 'react';
import { RefreshCw } from 'lucide-react';
import { iconBtnStyle, panelStyle } from '@/lib/dashboard/styles';
import { Escalation, SiteVisit } from '@/types/dashboard';

export function OpsTab({
  siteVisits,
  escalations,
  loadingOps,
  fetchOps,
}: {
  siteVisits: SiteVisit[];
  escalations: Escalation[];
  loadingOps: boolean;
  fetchOps: () => void;
}) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
      <div style={panelStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h2 style={{ fontSize: '16px', fontWeight: '600' }}>Scheduled Site Visits</h2>
          <button onClick={fetchOps} style={iconBtnStyle}><RefreshCw size={14} /> Refresh</button>
        </div>
        {siteVisits.length === 0 ? <p style={{ color: '#9ca3af', fontSize: '13px' }}>No site visits recorded yet.</p> : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {siteVisits.map((v) => (
              <div key={v.id} style={{ padding: '12px', background: '#0b0f19', border: '1px solid #232f48', borderRadius: '8px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: '600', color: '#fff' }}>
                  <span>Visit #{v.id.slice(0, 6)}</span>
                  <span style={{ color: '#10b981' }}>{v.status || 'Scheduled'}</span>
                </div>
                <p style={{ fontSize: '13px', color: '#9ca3af', marginTop: '4px' }}>
                  Date: {new Date(v.scheduled_time || v.visit_date).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={panelStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h2 style={{ fontSize: '16px', fontWeight: '600' }}>Human Escalations &amp; Support</h2>
          <button onClick={fetchOps} style={iconBtnStyle}><RefreshCw size={14} /> Refresh</button>
        </div>
        {escalations.length === 0 ? <p style={{ color: '#9ca3af', fontSize: '13px' }}>No escalated leads pending.</p> : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {escalations.map((e) => (
              <div key={e.id} style={{ padding: '12px', background: '#0b0f19', border: '1px solid #232f48', borderRadius: '8px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: '600', color: '#fff' }}>
                  <span>Escalation #{e.id.slice(0, 6)}</span>
                  <span style={{ color: '#ef4444' }}>{e.status || 'Pending'}</span>
                </div>
                <p style={{ fontSize: '13px', color: '#9ca3af', marginTop: '4px' }}>
                  Reason: {e.reason || 'Human agent requested by customer'}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
