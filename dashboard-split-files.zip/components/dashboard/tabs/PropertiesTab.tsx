import React from 'react';
import { MapPin, RefreshCw } from 'lucide-react';
import { iconBtnStyle, panelStyle } from '@/lib/dashboard/styles';
import { Property } from '@/types/dashboard';

export function PropertiesTab({
  properties,
  loadingProperties,
  fetchProperties,
}: {
  properties: Property[];
  loadingProperties: boolean;
  fetchProperties: () => void;
}) {
  return (
    <div style={panelStyle}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <h2 style={{ fontSize: '18px', fontWeight: '600' }}>Properties Inventory</h2>
        <button onClick={fetchProperties} style={iconBtnStyle}><RefreshCw size={14} /> Refresh</button>
      </div>
      {loadingProperties ? <p style={{ color: '#9ca3af' }}>Loading properties...</p> : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '16px' }}>
          {properties.map((p) => (
            <div key={p.id} style={{ background: '#0b0f19', border: '1px solid #232f48', borderRadius: '10px', padding: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#fff' }}>{p.title}</h3>
                <span style={{ fontSize: '11px', background: 'rgba(59,130,246,0.15)', color: '#60a5fa', padding: '2px 8px', borderRadius: '4px', textTransform: 'uppercase', fontWeight: '600' }}>
                  {p.possession_status || 'Active'}
                </span>
              </div>
              <p style={{ fontSize: '13px', color: '#9ca3af', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <MapPin size={14} /> {p.location}, {p.city}
              </p>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#e5e7eb', background: '#131b2e', padding: '10px', borderRadius: '6px', marginBottom: '12px' }}>
                <div>
                  <span style={{ color: '#9ca3af', fontSize: '11px', display: 'block' }}>Type</span>
                  <strong>{p.bhk_type} Flat</strong>
                </div>
                <div>
                  <span style={{ color: '#9ca3af', fontSize: '11px', display: 'block' }}>Area</span>
                  <strong>{p.sqft ? `${p.sqft} sqft` : '—'}</strong>
                </div>
                <div>
                  <span style={{ color: '#9ca3af', fontSize: '11px', display: 'block' }}>Price</span>
                  <strong style={{ color: '#10b981' }}>₹{(p.price / 10000000).toFixed(2)} Cr</strong>
                </div>
              </div>
              {Array.isArray(p.amenities) && p.amenities.length > 0 && (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                  {p.amenities.slice(0, 4).map((a: string, idx: number) => (
                    <span key={idx} style={{ fontSize: '11px', background: '#1e293b', color: '#9ca3af', padding: '2px 6px', borderRadius: '4px' }}>{a}</span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
