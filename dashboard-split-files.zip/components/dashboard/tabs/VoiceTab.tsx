import React from 'react';
import { Clock, Info, Loader2, Mic, PhoneCall, PhoneOff, RefreshCw, Send, Sliders, Sparkles, Volume2 } from 'lucide-react';
import { QuickVoiceChip } from '@/components/dashboard/ui/QuickVoiceChip';
import { StatusPill } from '@/components/dashboard/ui/StatusPill';
import { iconBtnStyle, panelStyle } from '@/lib/dashboard/styles';
import { useVoiceCall } from '@/hooks/useVoiceCall';

const LANGUAGE_OPTIONS = [
  ['hi-IN', 'Hindi (हिन्दी) 🇮🇳'],
  ['en-IN', 'English (Indian) 🇮🇳'],
] as const;

const GENDER_FILTERS = ['all', 'female', 'male'] as const;

export function VoiceTab({ voice }: { voice: ReturnType<typeof useVoiceCall> }) {
  const {
    voiceStatus,
    voiceLang,
    voiceSpeaker,
    voicePace,
    voiceGenderFilter,
    setVoiceGenderFilter,
    voiceTranscript,
    setVoiceTranscript,
    callDuration,
    audioLevel,
    interimText,
    voiceInput,
    setVoiceInput,
    noticeMsg,
    transcriptBottomRef,
    filteredVoices,
    startCall,
    endCall,
    processTurn,
    handleSendVoiceInput,
    formatDuration,
    selectLanguage,
    selectSpeaker,
    updatePace,
  } = voice;

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '440px 1fr', gap: '20px', alignItems: 'start' }}>
      {/* Call Control Console */}
      <div style={{ ...panelStyle, textAlign: 'center', padding: '28px 24px' }}>
        {/* AI Avatar */}
        <div style={{ position: 'relative', width: '100px', height: '100px', margin: '0 auto 16px' }}>
          <div style={{
            width: '100px', height: '100px', borderRadius: '50%',
            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: voiceStatus === 'speaking'
              ? '0 0 0 10px rgba(59,130,246,0.2), 0 0 0 20px rgba(59,130,246,0.1)'
              : voiceStatus === 'listening'
              ? '0 0 0 10px rgba(16,185,129,0.2), 0 0 0 20px rgba(16,185,129,0.1)'
              : 'none',
            transition: 'box-shadow 0.4s ease',
          }}>
            <Sparkles size={44} color="#fff" />
          </div>
          {/* Status Dot */}
          <div style={{
            position: 'absolute', bottom: 4, right: 4,
            width: 18, height: 18, borderRadius: '50%',
            background: voiceStatus === 'idle' || voiceStatus === 'ended' ? '#6b7280'
              : voiceStatus === 'listening' ? '#10b981'
              : voiceStatus === 'speaking' ? '#3b82f6'
              : '#f59e0b',
            border: '3px solid #131b2e',
            transition: 'background 0.3s',
          }} />
        </div>

        <h2 style={{ fontSize: '20px', fontWeight: '700', color: '#fff', marginBottom: '4px' }}>Realty AI Voice Agent</h2>
        <p style={{ fontSize: '13px', color: '#9ca3af', marginBottom: '16px' }}>
          Sarvam AI Bulbul v3 (TTS) + Gemini Sales Intelligence
        </p>

        {/* Call duration */}
        {(voiceStatus !== 'idle' && voiceStatus !== 'ended') && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', fontSize: '24px', fontWeight: '700', color: '#10b981', marginBottom: '16px', fontVariantNumeric: 'tabular-nums' }}>
            <Clock size={18} /> {formatDuration(callDuration)}
          </div>
        )}

        {/* Status Pill */}
        <div style={{ marginBottom: '16px' }}>
          <StatusPill status={voiceStatus} />
        </div>

        {/* Mic level bar when listening */}
        {voiceStatus === 'listening' && (
          <div style={{ marginBottom: '16px' }}>
            <div style={{ height: '8px', background: '#1e293b', borderRadius: '4px', overflow: 'hidden' }}>
              <div style={{ height: '100%', width: `${Math.max(10, audioLevel)}%`, background: 'linear-gradient(90deg, #10b981, #3b82f6)', borderRadius: '4px', transition: 'width 0.05s ease' }} />
            </div>
            <p style={{ fontSize: '12px', color: '#10b981', marginTop: '6px', fontWeight: '500' }}>
              🎙️ Listening live... speak your property query
            </p>
          </div>
        )}

        {/* Notice / Feedback banner */}
        {noticeMsg && (
          <div style={{ marginBottom: '16px', padding: '10px 12px', borderRadius: '8px', background: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.3)', color: '#fbbf24', fontSize: '12px', textAlign: 'left', display: 'flex', gap: '8px', alignItems: 'center' }}>
            <Info size={16} style={{ flexShrink: 0 }} />
            <span>{noticeMsg}</span>
          </div>
        )}

        {/* Language & Voice Selector */}
        {(voiceStatus === 'idle' || voiceStatus === 'ended') && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginBottom: '24px', textAlign: 'left', background: '#0b0f19', padding: '16px', borderRadius: '10px', border: '1px solid #1e293b' }}>
            <div>
              <label style={{ fontSize: '12px', color: '#9ca3af', marginBottom: '6px', display: 'block', fontWeight: '600' }}>
                🌐 Language Accent
              </label>
              <div style={{ display: 'flex', gap: '8px' }}>
                {LANGUAGE_OPTIONS.map(([code, label]) => (
                  <button key={code} onClick={() => selectLanguage(code)} style={{ flex: 1, padding: '8px 12px', borderRadius: '6px', border: `1px solid ${voiceLang === code ? '#3b82f6' : '#232f48'}`, background: voiceLang === code ? 'rgba(59,130,246,0.15)' : '#131b2e', color: voiceLang === code ? '#60a5fa' : '#9ca3af', fontSize: '12px', fontWeight: '600', cursor: 'pointer' }}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                <label style={{ fontSize: '12px', color: '#9ca3af', fontWeight: '600' }}>
                  🎙️ Select AI Voice ({filteredVoices.length} options)
                </label>
                <div style={{ display: 'flex', gap: '4px' }}>
                  {GENDER_FILTERS.map((g) => (
                    <button key={g} onClick={() => setVoiceGenderFilter(g)} style={{ padding: '2px 8px', borderRadius: '4px', border: 'none', background: voiceGenderFilter === g ? '#3b82f6' : '#1e293b', color: voiceGenderFilter === g ? '#fff' : '#9ca3af', fontSize: '10px', textTransform: 'capitalize', cursor: 'pointer' }}>
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', maxHeight: '200px', overflowY: 'auto', paddingRight: '4px' }}>
                {filteredVoices.map((v) => (
                  <button key={v.id} onClick={() => selectSpeaker(v.id)} style={{ textAlign: 'left', padding: '8px 10px', borderRadius: '6px', border: `1px solid ${voiceSpeaker === v.id ? '#8b5cf6' : '#232f48'}`, background: voiceSpeaker === v.id ? 'rgba(139,92,246,0.15)' : '#131b2e', color: voiceSpeaker === v.id ? '#a78bfa' : '#d1d5db', cursor: 'pointer' }}>
                    <div style={{ fontSize: '12px', fontWeight: '600' }}>{v.name}</div>
                    <div style={{ fontSize: '10px', color: '#9ca3af', marginTop: '2px' }}>{v.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Speech Pace Slider */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                <label style={{ fontSize: '12px', color: '#9ca3af', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Sliders size={12} /> Speech Cadence Speed
                </label>
                <span style={{ fontSize: '11px', color: '#60a5fa', fontWeight: '700' }}>{voicePace.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.85"
                max="1.15"
                step="0.05"
                value={voicePace}
                onChange={(e) => updatePace(parseFloat(e.target.value))}
                style={{ width: '100%', accentColor: '#3b82f6', cursor: 'pointer' }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px', color: '#6b7280', marginTop: '2px' }}>
                <span>Relaxed (0.85x)</span>
                <span>Conversational (1.0x)</span>
                <span>Fast (1.15x)</span>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', marginBottom: '20px' }}>
          {voiceStatus === 'idle' || voiceStatus === 'ended' ? (
            <button
              id="start-call-btn"
              onClick={startCall}
              style={{ padding: '14px 36px', borderRadius: '50px', border: 'none', background: 'linear-gradient(135deg, #10b981, #059669)', color: '#fff', fontWeight: '700', fontSize: '16px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 4px 20px rgba(16,185,129,0.4)' }}>
              <PhoneCall size={20} /> Start Voice Call
            </button>
          ) : (
            <>
              {voiceStatus === 'listening' && (
                <button
                  onClick={() => processTurn(interimText)}
                  style={{ padding: '12px 20px', borderRadius: '50px', background: '#2563eb', color: '#fff', fontWeight: '600', fontSize: '13px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', border: 'none', boxShadow: '0 4px 12px rgba(37,99,235,0.4)' }}>
                  <Mic size={16} /> Send Speech
                </button>
              )}
              <button
                id="end-call-btn"
                onClick={endCall}
                style={{ padding: '12px 24px', borderRadius: '50px', border: 'none', background: 'linear-gradient(135deg, #ef4444, #dc2626)', color: '#fff', fontWeight: '700', fontSize: '14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', boxShadow: '0 4px 16px rgba(239,68,68,0.4)' }}>
                <PhoneOff size={18} /> End Call
              </button>
            </>
          )}
        </div>

        {/* Interactive Speech Input & Quick Chips during call */}
        {(voiceStatus === 'listening' || voiceStatus === 'speaking' || voiceStatus === 'processing') && (
          <div style={{ marginTop: '16px', borderTop: '1px solid #1e293b', paddingTop: '16px', textAlign: 'left' }}>
            <label style={{ fontSize: '12px', color: '#9ca3af', marginBottom: '8px', display: 'block' }}>
              💬 Speak into mic or type a test message:
            </label>

            <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
              <input
                type="text"
                placeholder="e.g. 3BHK flat in Noida under 1.5 Cr..."
                value={voiceInput}
                onChange={(e) => setVoiceInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendVoiceInput()}
                style={{ flex: 1, padding: '10px 14px', borderRadius: '8px', border: '1px solid #232f48', background: '#0b0f19', color: '#fff', fontSize: '13px', outline: 'none' }}
              />
              <button
                onClick={() => handleSendVoiceInput()}
                style={{ padding: '10px 16px', borderRadius: '8px', border: 'none', background: '#3b82f6', color: '#fff', fontWeight: '600', fontSize: '13px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <Send size={14} /> Send
              </button>
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              <QuickVoiceChip text="Noida 3BHK under 1.5 Cr?" onClick={(t) => handleSendVoiceInput(t)} />
              <QuickVoiceChip text="Book Saturday site visit" onClick={(t) => handleSendVoiceInput(t)} />
              <QuickVoiceChip text="Connect with sales manager" onClick={(t) => handleSendVoiceInput(t)} />
            </div>
          </div>
        )}
      </div>

      {/* Live Transcript & Real-Time Voice Wave Panel */}
      <div style={panelStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', borderBottom: '1px solid #232f48', paddingBottom: '12px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '600', color: '#fff', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Volume2 size={18} style={{ color: '#8b5cf6' }} /> Live Call Transcript
          </h3>
          {voiceTranscript.length > 0 && (
            <button onClick={() => setVoiceTranscript([])} style={iconBtnStyle}>
              <RefreshCw size={12} /> Clear Log
            </button>
          )}
        </div>

        <div style={{ height: '560px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '14px', paddingRight: '4px' }}>
          {voiceTranscript.length === 0 && !interimText && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: '12px' }}>
              <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'rgba(139,92,246,0.1)', border: '1px solid rgba(139,92,246,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Mic size={28} color="#a78bfa" />
              </div>
              <p style={{ color: '#6b7280', fontSize: '14px', textAlign: 'center', lineHeight: '1.6' }}>
                Click <strong>Start Voice Call</strong> to speak live with Realty AI.<br />
                Select from 14 distinct male/female Sarvam Bulbul v3 voices!
              </p>
            </div>
          )}

          {/* Speech Log */}
          {voiceTranscript.map((t, i) => (
            <div key={i} style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
              <div style={{
                flexShrink: 0, width: '36px', height: '36px', borderRadius: '50%',
                background: t.speaker === 'You' ? 'rgba(59,130,246,0.2)' : 'rgba(139,92,246,0.2)',
                border: `1px solid ${t.speaker === 'You' ? 'rgba(59,130,246,0.4)' : 'rgba(139,92,246,0.4)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: '700',
                color: t.speaker === 'You' ? '#60a5fa' : '#a78bfa',
              }}>
                {t.speaker === 'You' ? 'U' : 'AI'}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '4px' }}>
                  <span style={{ fontSize: '13px', fontWeight: '600', color: t.speaker === 'You' ? '#60a5fa' : '#a78bfa' }}>{t.speaker}</span>
                  <span style={{ fontSize: '11px', color: '#4b5563' }}>{t.time}</span>
                </div>
                <div style={{ fontSize: '14px', color: '#e5e7eb', lineHeight: '1.6', background: t.speaker === 'Realty AI' ? '#0f1929' : 'rgba(255,255,255,0.03)', padding: '10px 14px', borderRadius: '10px', border: t.speaker === 'Realty AI' ? '1px solid #1e293b' : '1px solid rgba(255,255,255,0.06)' }}>
                  {t.text}
                </div>
              </div>
            </div>
          ))}

          {/* Live interim text preview as user speaks */}
          {interimText && (
            <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start', opacity: 0.8 }}>
              <div style={{ flexShrink: 0, width: '36px', height: '36px', borderRadius: '50%', background: 'rgba(16,185,129,0.2)', border: '1px solid rgba(16,185,129,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: '700', color: '#10b981' }}>
                U
              </div>
              <div style={{ flex: 1 }}>
                <span style={{ fontSize: '12px', color: '#10b981', fontStyle: 'italic', marginBottom: '2px', display: 'block' }}>Speaking live...</span>
                <div style={{ fontSize: '14px', color: '#6ee7b7', fontStyle: 'italic', background: 'rgba(16,185,129,0.1)', padding: '10px 14px', borderRadius: '10px', border: '1px dashed rgba(16,185,129,0.3)' }}>
                  "{interimText}"
                </div>
              </div>
            </div>
          )}

          {/* Processing indicator */}
          {voiceStatus === 'processing' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: '#60a5fa', fontSize: '13px', fontStyle: 'italic', padding: '10px 14px', background: 'rgba(59,130,246,0.1)', borderRadius: '8px', border: '1px solid rgba(59,130,246,0.2)' }}>
              <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> Processing query with Sarvam AI + Gemini...
            </div>
          )}

          <div ref={transcriptBottomRef} />
        </div>
      </div>
    </div>
  );
}
