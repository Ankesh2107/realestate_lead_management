import React from 'react';
import { Send, TrendingUp } from 'lucide-react';
import { QuickChip } from '@/components/dashboard/ui/QuickChip';
import { LeadRow } from '@/components/dashboard/ui/LeadRow';
import { panelStyle } from '@/lib/dashboard/styles';
import { useChatSimulator } from '@/hooks/useChatSimulator';

const CHANNELS = ['whatsapp', 'instagram', 'facebook', 'web_test'];

export function ChatTab({ chat }: { chat: ReturnType<typeof useChatSimulator> }) {
  const {
    channel,
    setChannel,
    sessionId,
    inputMsg,
    setInputMsg,
    messages,
    currentLead,
    isTyping,
    chatBottomRef,
    handleSendChat,
  } = chat;

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '20px' }}>
      <div style={panelStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', borderBottom: '1px solid #232f48', paddingBottom: '12px' }}>
          <div style={{ display: 'flex', gap: '8px' }}>
            {CHANNELS.map((ch) => (
              <button key={ch} onClick={() => setChannel(ch)} style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #232f48', background: channel === ch ? '#3b82f6' : '#131b2e', color: '#fff', fontSize: '13px', cursor: 'pointer', textTransform: 'capitalize' }}>
                {ch.replace('_', ' ')}
              </button>
            ))}
          </div>
          <span style={{ fontSize: '12px', color: '#9ca3af' }}>Session: {sessionId}</span>
        </div>

        <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', overflowX: 'auto', paddingBottom: '4px' }}>
          <QuickChip text="Hi, do you have any 3BHK flats in Noida under 1.5 Cr?" onClick={(t) => handleSendChat(t)} />
          <QuickChip text="Can I schedule a site visit this Saturday?" onClick={(t) => handleSendChat(t)} />
          <QuickChip text="I want to talk to a human manager." onClick={(t) => handleSendChat(t)} />
        </div>

        <div style={{ height: '420px', overflowY: 'auto', border: '1px solid #232f48', borderRadius: '8px', padding: '16px', background: '#0b0f19', marginBottom: '16px' }}>
          {messages.length === 0 && <p style={{ color: '#6b7280', fontSize: '14px', textAlign: 'center', marginTop: '160px' }}>Start a conversation to test Realty AI multi-turn sales pipeline...</p>}
          {messages.map((m, idx) => (
            <div key={idx} style={{ display: 'flex', justifyContent: m.sender === 'customer' ? 'flex-end' : 'flex-start', marginBottom: '12px' }}>
              <div style={{ maxWidth: '75%', padding: '10px 14px', borderRadius: '12px', fontSize: '14px', lineHeight: '1.5', background: m.sender === 'customer' ? '#2563eb' : m.sender === 'ai' ? '#1e293b' : '#374151', color: '#fff', border: m.sender === 'ai' ? '1px solid #334155' : 'none' }}>
                {m.text}
              </div>
            </div>
          ))}
          {isTyping && <div style={{ color: '#9ca3af', fontSize: '13px', fontStyle: 'italic' }}>Realty AI is thinking and querying properties...</div>}
          <div ref={chatBottomRef} />
        </div>

        <div style={{ display: 'flex', gap: '10px' }}>
          <input type="text" placeholder="Type your property inquiry..." value={inputMsg} onChange={(e) => setInputMsg(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSendChat()} style={{ flex: 1, padding: '12px 16px', borderRadius: '8px', border: '1px solid #232f48', background: '#0b0f19', color: '#fff', outline: 'none' }} />
          <button onClick={() => handleSendChat()} disabled={isTyping} style={{ padding: '12px 20px', borderRadius: '8px', border: 'none', background: '#3b82f6', color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: '600' }}>
            <Send size={16} /> Send
          </button>
        </div>
      </div>

      <div style={panelStyle}>
        <h3 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '16px', borderBottom: '1px solid #232f48', paddingBottom: '8px', color: '#fff', display: 'flex', alignItems: 'center', gap: '6px' }}>
          <TrendingUp size={16} style={{ color: '#10b981' }} /> Live Lead Inspector
        </h3>
        {currentLead ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '13px' }}>
            <LeadRow label="Name" value={currentLead.name || 'Not provided'} />
            <LeadRow label="Phone" value={currentLead.phone || 'Not provided'} />
            <LeadRow label="Channel" value={currentLead.channel} />
            <LeadRow label="Intent" value={currentLead.intent || '—'} />
            <LeadRow label="Purpose" value={currentLead.purpose || '—'} />
            <LeadRow label="Timeline" value={currentLead.timeline || '—'} />
            <LeadRow label="Budget Min" value={currentLead.budget_min ? `₹${currentLead.budget_min.toLocaleString()}` : '—'} />
            <LeadRow label="Budget Max" value={currentLead.budget_max ? `₹${currentLead.budget_max.toLocaleString()}` : '—'} />
            <LeadRow label="Locations" value={(currentLead.preferred_locations || []).join(', ') || '—'} />
            <LeadRow label="BHK" value={(currentLead.bhk_options || []).join(', ') || '—'} />
            <LeadRow label="Status" value={currentLead.status} />
            <LeadRow label="Temperature" value={currentLead.temperature} />
            <LeadRow label="Lead Score" value={`${currentLead.lead_score ?? 0} / 100`} />
          </div>
        ) : (
          <p style={{ color: '#6b7280', fontSize: '13px' }}>Send a message to see Supabase real-time lead updates.</p>
        )}
      </div>
    </div>
  );
}
