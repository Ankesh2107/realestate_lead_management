import React from 'react';
import { VoiceStatus } from '@/types/dashboard';

export function StatusPill({ status }: { status: VoiceStatus }) {
  const configs: Record<VoiceStatus, { label: string; bg: string; color: string; border: string }> = {
    idle: { label: 'Ready for Call', bg: 'rgba(107,114,128,0.15)', color: '#9ca3af', border: '1px solid rgba(107,114,128,0.3)' },
    connecting: { label: 'Connecting Agent...', bg: 'rgba(245,158,11,0.15)', color: '#fbbf24', border: '1px solid rgba(245,158,11,0.3)' },
    listening: { label: '🎙️ Listening to You...', bg: 'rgba(16,185,129,0.15)', color: '#34d399', border: '1px solid rgba(16,185,129,0.3)' },
    processing: { label: '⚡ Thinking & Querying...', bg: 'rgba(59,130,246,0.15)', color: '#60a5fa', border: '1px solid rgba(59,130,246,0.3)' },
    speaking: { label: '🔊 Agent Speaking...', bg: 'rgba(139,92,246,0.15)', color: '#a78bfa', border: '1px solid rgba(139,92,246,0.3)' },
    ended: { label: 'Call Ended', bg: 'rgba(239,68,68,0.15)', color: '#f87171', border: '1px solid rgba(239,68,68,0.3)' },
  };

  const cfg = configs[status] || configs.idle;

  return (
    <span style={{ display: 'inline-block', padding: '6px 16px', borderRadius: '20px', background: cfg.bg, color: cfg.color, border: cfg.border, fontSize: '13px', fontWeight: '600' }}>
      {cfg.label}
    </span>
  );
}
