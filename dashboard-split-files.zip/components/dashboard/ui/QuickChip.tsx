import React from 'react';

export function QuickChip({ text, onClick }: { text: string; onClick: (t: string) => void }) {
  return (
    <button
      onClick={() => onClick(text)}
      style={{
        whiteSpace: 'nowrap',
        padding: '6px 12px',
        borderRadius: '16px',
        border: '1px solid #232f48',
        background: '#131b2e',
        color: '#9ca3af',
        fontSize: '12px',
        cursor: 'pointer',
      }}
    >
      {text}
    </button>
  );
}
