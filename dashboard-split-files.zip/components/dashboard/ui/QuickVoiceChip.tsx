import React from 'react';

export function QuickVoiceChip({ text, onClick }: { text: string; onClick: (t: string) => void }) {
  return (
    <button
      onClick={() => onClick(text)}
      style={{
        padding: '4px 10px',
        borderRadius: '12px',
        border: '1px solid rgba(59,130,246,0.3)',
        background: 'rgba(59,130,246,0.1)',
        color: '#60a5fa',
        fontSize: '11px',
        cursor: 'pointer',
      }}
    >
      "{text}"
    </button>
  );
}
