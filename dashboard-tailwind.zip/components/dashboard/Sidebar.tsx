'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Building2, ClipboardList, LayoutGrid, PhoneCall, Sparkles, Users } from 'lucide-react';
import { useHealthCheck } from '@/hooks/useHealthCheck';

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Home', icon: LayoutGrid, exact: true },
  { href: '/dashboard/voice', label: 'Voice Agent', icon: PhoneCall },
  { href: '/dashboard/leads', label: 'Leads CRM', icon: Users },
  { href: '/dashboard/properties', label: 'Properties', icon: Building2 },
  { href: '/dashboard/ops', label: 'Ops & Escalations', icon: ClipboardList },
];

export function Sidebar() {
  const pathname = usePathname();
  const { health } = useHealthCheck();

  return (
    <aside className="flex min-h-screen w-64 shrink-0 flex-col gap-7 border-r border-border bg-sidebar p-4">
      <div className="flex items-center gap-2.5 px-2 py-1">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-ink">
          <Sparkles size={17} className="text-white" />
        </div>
        <span className="text-[17px] font-bold tracking-tight text-ink">Realty AI</span>
      </div>

      <nav className="flex flex-col gap-1">
        {NAV_ITEMS.map((item) => {
          const active = item.exact ? pathname === item.href : pathname?.startsWith(item.href);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={[
                'flex items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm transition-colors',
                active ? 'bg-ink font-semibold text-white' : 'font-medium text-muted hover:bg-black/5',
              ].join(' ')}
            >
              <Icon size={17} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto flex flex-col gap-2">
        <div className="flex flex-col gap-1.5 rounded-2xl border border-border bg-surface p-3.5">
          <span className="mb-0.5 text-[10.5px] font-bold uppercase tracking-wide text-faint">System Status</span>
          <div className="flex items-center gap-2">
            <span className={`h-[7px] w-[7px] shrink-0 rounded-full ${health.dbOk ? 'bg-success' : 'bg-danger'}`} />
            <span className="text-xs text-muted">Supabase DB</span>
          </div>
          <div className="flex items-center gap-2">
            <span className={`h-[7px] w-[7px] shrink-0 rounded-full ${health.geminiOk ? 'bg-success' : 'bg-danger'}`} />
            <span className="text-xs text-muted">Gemini AI Engine</span>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-surface p-3.5">
          <p className="mb-1 text-xs font-bold text-ink">Skyline Realty</p>
          <p className="text-[11.5px] leading-relaxed text-faint">
            Multilingual AI sales agent across WhatsApp, Instagram, Facebook &amp; Voice.
          </p>
        </div>
      </div>
    </aside>
  );
}
