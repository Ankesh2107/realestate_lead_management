import React from 'react';
import { RefreshCw, Users } from 'lucide-react';
import { iconBtnClass, panelClass, statusBadgeClass, tableClass, tempBadgeClass } from '@/lib/dashboard/styles';
import { Lead } from '@/types/dashboard';

const th = 'border-b border-border px-3 pb-2.5 text-left text-[11px] font-bold uppercase tracking-wide text-faint';
const td = 'border-b border-border-soft px-3 py-3.5 text-ink';

export function LeadsTab({
  leads,
  loadingLeads,
  fetchLeads,
}: {
  leads: Lead[];
  loadingLeads: boolean;
  fetchLeads: () => void;
}) {
  return (
    <div className={panelClass}>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-base font-bold text-ink">Leads Directory</h2>
        <button onClick={fetchLeads} className={iconBtnClass}>
          <RefreshCw size={14} /> Refresh
        </button>
      </div>
      {loadingLeads ? (
        <p className="text-[13px] text-muted">Loading leads...</p>
      ) : leads.length === 0 ? (
        <div className="flex flex-col items-center gap-2.5 py-12 text-faint">
          <Users size={28} />
          <p className="text-[13px]">No leads yet.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className={tableClass}>
            <thead>
              <tr>
                <th className={th}>Name / ID</th>
                <th className={th}>Channel</th>
                <th className={th}>Intent</th>
                <th className={th}>Budget</th>
                <th className={th}>Locations</th>
                <th className={th}>Status</th>
                <th className={th}>Temp</th>
                <th className={th}>Score</th>
                <th className={th}>Last Active</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((l) => (
                <tr key={l.id}>
                  <td className={`${td} font-semibold`}>{l.name || l.external_user_id}</td>
                  <td className={`${td} capitalize`}>{l.channel}</td>
                  <td className={td}>{l.intent || '—'}</td>
                  <td className={td}>{l.budget_max ? `₹${(l.budget_max / 100000).toFixed(1)}L` : '—'}</td>
                  <td className={td}>{(l.preferred_locations || []).join(', ') || '—'}</td>
                  <td className={td}>
                    <span className={statusBadgeClass(l.status)}>{l.status}</span>
                  </td>
                  <td className={td}>
                    <span className={tempBadgeClass(l.temperature)}>{l.temperature}</span>
                  </td>
                  <td className={`${td} font-bold`}>{l.lead_score ?? 0}</td>
                  <td className={`${td} text-xs text-faint`}>{new Date(l.updated_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
