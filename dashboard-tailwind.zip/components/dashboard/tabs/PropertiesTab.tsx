import React from 'react';
import { Building2, MapPin, RefreshCw } from 'lucide-react';
import { iconBtnClass, panelClass } from '@/lib/dashboard/styles';
import { Property } from '@/types/dashboard';

export function PropertiesTab({
  properties,
  loadingProperties,
  fetchProperties,
}: {
  properties: Property[];
  loadingProperties: boolean;
  fetchProperties: () => void;
}) {
  return (
    <div className={panelClass}>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-base font-bold text-ink">Properties Inventory</h2>
        <button onClick={fetchProperties} className={iconBtnClass}>
          <RefreshCw size={14} /> Refresh
        </button>
      </div>
      {loadingProperties ? (
        <p className="text-[13px] text-muted">Loading properties...</p>
      ) : properties.length === 0 ? (
        <div className="flex flex-col items-center gap-2.5 py-12 text-faint">
          <Building2 size={28} />
          <p className="text-[13px]">No properties listed yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {properties.map((p) => (
            <div key={p.id} className="rounded-2xl border border-border bg-surface-alt p-4">
              <div className="mb-2 flex items-start justify-between gap-2">
                <h3 className="text-[15.5px] font-bold text-ink">{p.title}</h3>
                <span className="shrink-0 rounded-[5px] bg-primary-soft px-2 py-0.5 text-[10.5px] font-bold uppercase text-primary">
                  {p.possession_status || 'Active'}
                </span>
              </div>
              <p className="mb-3 flex items-center gap-1 text-[13px] text-muted">
                <MapPin size={14} /> {p.location}, {p.city}
              </p>
              <div className="mb-3 flex justify-between rounded-xl border border-border bg-surface p-2.5 text-[13px] text-ink">
                <div>
                  <span className="block text-[11px] text-faint">Type</span>
                  <strong>{p.bhk_type} Flat</strong>
                </div>
                <div>
                  <span className="block text-[11px] text-faint">Area</span>
                  <strong>{p.sqft ? `${p.sqft} sqft` : '—'}</strong>
                </div>
                <div>
                  <span className="block text-[11px] text-faint">Price</span>
                  <strong className="text-success">₹{(p.price / 10000000).toFixed(2)} Cr</strong>
                </div>
              </div>
              {Array.isArray(p.amenities) && p.amenities.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {p.amenities.slice(0, 4).map((a: string, idx: number) => (
                    <span key={idx} className="rounded-[5px] border border-border bg-surface px-2 py-0.5 text-[11px] text-muted">
                      {a}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
