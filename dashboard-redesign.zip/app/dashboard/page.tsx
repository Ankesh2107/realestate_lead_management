'use client';

import React from 'react';
import Link from 'next/link';
import { ArrowUpRight, Building2, ClipboardList, Flame, PhoneCall, Sparkles, Users } from 'lucide-react';
import { StatCard } from '@/components/dashboard/ui/StatCard';
import { statusBadgeStyle, tempBadgeStyle } from '@/lib/dashboard/styles';
import { useOverviewStats } from '@/hooks/useOverviewStats';

export default function DashboardHome() {
  const { stats, loading } = useOverviewStats();

  const coldLeads = Math.max(stats.totalLeads - stats.hotLeads - stats.warmLeads, 0);
  const total = Math.max(stats.totalLeads, 1);

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '28px', gap: '16px' }}>
        <div>
          <h1 style={{ fontSize: '28px', fontWeight: 700, color: 'var(--ink)', letterSpacing: '-0.01em' }}>
            Welcome back 👋
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginTop: '4px' }}>
            Here&apos;s how Realty AI is performing across your pipeline today.
          </p>
        </div>
        <Link
          href="/dashboard/voice"
          style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '11px 18px', borderRadius: '12px', background: 'var(--ink)', color: '#fff', fontSize: '13.5px', fontWeight: 600 }}
        >
          <PhoneCall size={16} /> Start a test call
        </Link>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '18px', marginBottom: '22px' }}>
        <StatCard label="Total Leads" value={loading ? '—' : stats.totalLeads} icon={<Users size={16} />} tint="blue" />
        <StatCard label="Hot Leads" value={loading ? '—' : stats.hotLeads} icon={<Flame size={16} />} tint="amber" />
        <StatCard label="Properties Listed" value={loading ? '—' : stats.totalProperties} icon={<Building2 size={16} />} tint="violet" />
        <StatCard label="Pending Ops" value={loading ? '—' : stats.pendingVisits + stats.pendingEscalations} icon={<ClipboardList size={16} />} tint="green" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '20px' }}>
        {/* Recent leads */}
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-md)', padding: '22px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--ink)' }}>Recent Leads</h2>
            <Link href="/dashboard/leads" style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '13px', fontWeight: 600, color: 'var(--primary)' }}>
              View all <ArrowUpRight size={14} />
            </Link>
          </div>

          {loading ? (
            <p style={{ color: 'var(--text-muted)', fontSize: '13px' }}>Loading...</p>
          ) : stats.recentLeads.length === 0 ? (
            <p style={{ color: 'var(--text-muted)', fontSize: '13px' }}>No leads yet — once WhatsApp, Instagram or Facebook messages come in, they&apos;ll show up here.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {stats.recentLeads.map((l, idx) => (
                <div
                  key={l.id}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '13px 0',
                    borderTop: idx === 0 ? 'none' : '1px solid var(--border-soft)',
                  }}
                >
                  <div>
                    <p style={{ fontSize: '14px', fontWeight: 600, color: 'var(--ink)' }}>{l.name || l.external_user_id}</p>
                    <p style={{ fontSize: '12px', color: 'var(--text-faint)', textTransform: 'capitalize', marginTop: '2px' }}>
                      {l.channel} · {l.intent || 'unknown intent'}
                    </p>
                  </div>
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <span style={tempBadgeStyle(l.temperature)}>{l.temperature}</span>
                    <span style={statusBadgeStyle(l.status)}>{l.status}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
          <div style={{ background: 'var(--ink)', borderRadius: 'var(--radius-lg)', padding: '22px', color: '#fff', boxShadow: 'var(--shadow-lg)' }}>
            <Sparkles size={20} style={{ marginBottom: '10px', opacity: 0.9 }} />
            <p style={{ fontSize: '15px', fontWeight: 600, lineHeight: 1.5, marginBottom: '14px' }}>
              Talk to Realty AI live — hear how it qualifies a lead in Hindi or English before it ever reaches a real customer.
            </p>
            <Link
              href="/dashboard/voice"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '9px 14px', borderRadius: '10px', background: 'rgba(255,255,255,0.12)', fontSize: '13px', fontWeight: 600 }}
            >
              Open Voice Agent <ArrowUpRight size={14} />
            </Link>
          </div>

          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-md)', padding: '22px' }}>
            <h2 style={{ fontSize: '14px', fontWeight: 700, color: 'var(--ink)', marginBottom: '14px' }}>Lead Temperature</h2>
            <div style={{ display: 'flex', height: '10px', borderRadius: '6px', overflow: 'hidden', marginBottom: '14px' }}>
              <div style={{ width: `${(stats.hotLeads / total) * 100}%`, background: 'var(--danger)' }} />
              <div style={{ width: `${(stats.warmLeads / total) * 100}%`, background: 'var(--warning)' }} />
              <div style={{ width: `${(coldLeads / total) * 100}%`, background: 'var(--primary)' }} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '12.5px' }}>
              <LegendRow color="var(--danger)" label="Hot" value={stats.hotLeads} />
              <LegendRow color="var(--warning)" label="Warm" value={stats.warmLeads} />
              <LegendRow color="var(--primary)" label="Cold" value={coldLeads} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LegendRow({ color, label, value }: { color: string; label: string; value: number }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: color }} />
        <span style={{ color: 'var(--text-muted)' }}>{label}</span>
      </div>
      <span style={{ fontWeight: 700, color: 'var(--ink)' }}>{value}</span>
    </div>
  );
}
