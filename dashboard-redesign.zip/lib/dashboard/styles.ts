import React from 'react';

export const panelStyle: React.CSSProperties = {
  background: 'var(--surface)',
  borderRadius: 'var(--radius-lg)',
  border: '1px solid var(--border)',
  boxShadow: 'var(--shadow-md)',
  padding: '22px',
};

export const iconBtnStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: '6px',
  padding: '7px 12px',
  borderRadius: '10px',
  border: '1px solid var(--border)',
  background: 'var(--surface)',
  color: 'var(--text-muted)',
  fontSize: '12px',
  fontWeight: 600,
  cursor: 'pointer',
};

export const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: '13px',
  color: 'var(--text-main)',
};

export function healthBadgeStyle(ok: boolean): React.CSSProperties {
  return {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    padding: '6px 12px',
    borderRadius: '20px',
    fontSize: '12px',
    fontWeight: '600',
    background: ok ? 'var(--success-soft)' : 'var(--danger-soft)',
    color: ok ? 'var(--success)' : 'var(--danger)',
    border: `1px solid ${ok ? 'rgba(22,163,74,0.2)' : 'rgba(224,67,58,0.2)'}`,
  };
}

export function statusBadgeStyle(status: string): React.CSSProperties {
  const isHot = status === 'qualified' || status === 'visit_scheduled';
  return {
    padding: '3px 10px',
    borderRadius: '6px',
    fontSize: '11px',
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: '0.02em',
    background: isHot ? 'var(--success-soft)' : '#f1efe7',
    color: isHot ? 'var(--success)' : 'var(--text-muted)',
  };
}

export function tempBadgeStyle(temp: string): React.CSSProperties {
  const isHot = temp === 'HOT';
  const isWarm = temp === 'WARM';
  return {
    padding: '3px 10px',
    borderRadius: '6px',
    fontSize: '11px',
    fontWeight: '700',
    background: isHot ? 'var(--danger-soft)' : isWarm ? 'var(--warning-soft)' : 'var(--primary-soft)',
    color: isHot ? 'var(--danger)' : isWarm ? 'var(--warning)' : 'var(--primary)',
  };
}
