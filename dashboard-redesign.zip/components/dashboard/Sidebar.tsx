'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Building2, ClipboardList, LayoutGrid, PhoneCall, Sparkles, Users } from 'lucide-react';
import { useHealthCheck } from '@/hooks/useHealthCheck';

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Home', icon: LayoutGrid, exact: true },
  { href: '/dashboard/voice', label: 'Voice Agent', icon: PhoneCall },
  { href: '/dashboard/leads', label: 'Leads CRM', icon: Users },
  { href: '/dashboard/properties', label: 'Properties', icon: Building2 },
  { href: '/dashboard/ops', label: 'Ops & Escalations', icon: ClipboardList },
];

export function Sidebar() {
  const pathname = usePathname();
  const { health } = useHealthCheck();

  return (
    <aside
      style={{
        width: '252px',
        flexShrink: 0,
        background: 'var(--sidebar-bg)',
        borderRight: '1px solid var(--border)',
        padding: '22px 16px',
        display: 'flex',
        flexDirection: 'column',
        gap: '28px',
        minHeight: '100vh',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '4px 8px' }}>
        <div
          style={{
            width: '34px',
            height: '34px',
            borderRadius: '10px',
            background: 'var(--ink)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Sparkles size={17} color="#fff" />
        </div>
        <span style={{ fontSize: '17px', fontWeight: 700, color: 'var(--ink)', letterSpacing: '-0.01em' }}>
          Realty AI
        </span>
      </div>

      <nav style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
        {NAV_ITEMS.map((item) => {
          const active = item.exact ? pathname === item.href : pathname?.startsWith(item.href);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '11px',
                padding: '10px 14px',
                borderRadius: '12px',
                fontSize: '14px',
                fontWeight: active ? 600 : 500,
                background: active ? 'var(--ink)' : 'transparent',
                color: active ? '#fff' : 'var(--text-muted)',
                transition: 'background 0.15s, color 0.15s',
              }}
            >
              <Icon size={17} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div style={{ marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', padding: '12px 14px', borderRadius: 'var(--radius-md)', background: 'var(--surface)', border: '1px solid var(--border)' }}>
          <span style={{ fontSize: '10.5px', fontWeight: 700, color: 'var(--text-faint)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '2px' }}>
            System Status
          </span>
          <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
            <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: health.dbOk ? 'var(--success)' : 'var(--danger)', flexShrink: 0 }} />
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Supabase DB</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
            <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: health.geminiOk ? 'var(--success)' : 'var(--danger)', flexShrink: 0 }} />
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Gemini AI Engine</span>
          </div>
        </div>

        <div style={{ padding: '16px 14px', borderRadius: 'var(--radius-md)', background: 'var(--surface)', border: '1px solid var(--border)' }}>
          <p style={{ fontSize: '12px', fontWeight: 700, color: 'var(--ink)', marginBottom: '4px' }}>Skyline Realty</p>
          <p style={{ fontSize: '11.5px', color: 'var(--text-faint)', lineHeight: 1.5 }}>
            Multilingual AI sales agent across WhatsApp, Instagram, Facebook &amp; Voice.
          </p>
        </div>
      </div>
    </aside>
  );
}
