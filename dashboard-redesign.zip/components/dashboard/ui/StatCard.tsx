import React from 'react';

export function StatCard({
  label,
  value,
  icon,
  tint,
}: {
  label: string;
  value: React.ReactNode;
  icon: React.ReactNode;
  tint: 'blue' | 'green' | 'amber' | 'violet';
}) {
  const tints: Record<string, { bg: string; fg: string }> = {
    blue: { bg: 'var(--primary-soft)', fg: 'var(--primary)' },
    green: { bg: 'var(--success-soft)', fg: 'var(--success)' },
    amber: { bg: 'var(--warning-soft)', fg: 'var(--warning)' },
    violet: { bg: 'var(--violet-soft)', fg: 'var(--violet)' },
  };
  const c = tints[tint];

  return (
    <div
      style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'var(--shadow-sm)',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        gap: '14px',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
          {label}
        </span>
        <div style={{ width: '32px', height: '32px', borderRadius: '9px', background: c.bg, color: c.fg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {icon}
        </div>
      </div>
      <span style={{ fontSize: '28px', fontWeight: 700, color: 'var(--ink)', letterSpacing: '-0.01em' }}>{value}</span>
    </div>
  );
}
