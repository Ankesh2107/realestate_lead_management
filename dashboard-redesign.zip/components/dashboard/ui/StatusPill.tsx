import React from 'react';
import { VoiceStatus } from '@/types/dashboard';

export function StatusPill({ status }: { status: VoiceStatus }) {
  const configs: Record<VoiceStatus, { label: string; bg: string; color: string; border: string }> = {
    idle: { label: 'Ready for Call', bg: '#f1efe7', color: 'var(--text-muted)', border: '1px solid var(--border)' },
    connecting: { label: 'Connecting Agent...', bg: 'var(--warning-soft)', color: 'var(--warning)', border: '1px solid rgba(217,138,31,0.25)' },
    listening: { label: '🎙️ Listening to You...', bg: 'var(--success-soft)', color: 'var(--success)', border: '1px solid rgba(22,163,74,0.25)' },
    processing: { label: '⚡ Thinking & Querying...', bg: 'var(--primary-soft)', color: 'var(--primary)', border: '1px solid rgba(47,111,237,0.25)' },
    speaking: { label: '🔊 Agent Speaking...', bg: 'var(--violet-soft)', color: 'var(--violet)', border: '1px solid rgba(124,92,255,0.25)' },
    ended: { label: 'Call Ended', bg: 'var(--danger-soft)', color: 'var(--danger)', border: '1px solid rgba(224,67,58,0.25)' },
  };

  const cfg = configs[status] || configs.idle;

  return (
    <span style={{ display: 'inline-block', padding: '6px 16px', borderRadius: '20px', background: cfg.bg, color: cfg.color, border: cfg.border, fontSize: '13px', fontWeight: '600' }}>
      {cfg.label}
    </span>
  );
}
