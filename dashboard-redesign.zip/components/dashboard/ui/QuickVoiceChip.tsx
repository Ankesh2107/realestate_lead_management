import React from 'react';

export function QuickVoiceChip({ text, onClick }: { text: string; onClick: (t: string) => void }) {
  return (
    <button
      onClick={() => onClick(text)}
      style={{
        padding: '4px 10px',
        borderRadius: '12px',
        border: '1px solid rgba(47,111,237,0.25)',
        background: 'var(--primary-soft)',
        color: 'var(--primary)',
        fontSize: '11px',
        cursor: 'pointer',
      }}
    >
      "{text}"
    </button>
  );
}
