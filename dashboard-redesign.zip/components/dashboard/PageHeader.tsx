import React from 'react';

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '26px', gap: '16px' }}>
      <div>
        <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--ink)', letterSpacing: '-0.01em' }}>{title}</h1>
        {subtitle && <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginTop: '4px' }}>{subtitle}</p>}
      </div>
      {actions && <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexShrink: 0 }}>{actions}</div>}
    </div>
  );
}
