import React from 'react';
import { Building2, MapPin, RefreshCw } from 'lucide-react';
import { iconBtnStyle, panelStyle } from '@/lib/dashboard/styles';
import { Property } from '@/types/dashboard';

export function PropertiesTab({
  properties,
  loadingProperties,
  fetchProperties,
}: {
  properties: Property[];
  loadingProperties: boolean;
  fetchProperties: () => void;
}) {
  return (
    <div style={panelStyle}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: '700', color: 'var(--ink)' }}>Properties Inventory</h2>
        <button onClick={fetchProperties} style={iconBtnStyle}><RefreshCw size={14} /> Refresh</button>
      </div>
      {loadingProperties ? (
        <p style={{ color: 'var(--text-muted)', fontSize: '13px' }}>Loading properties...</p>
      ) : properties.length === 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', padding: '50px 0', color: 'var(--text-faint)' }}>
          <Building2 size={28} />
          <p style={{ fontSize: '13px' }}>No properties listed yet.</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '16px' }}>
          {properties.map((p) => (
            <div key={p.id} style={{ background: 'var(--surface-alt)', border: '1px solid var(--border)', borderRadius: '14px', padding: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px', gap: '8px' }}>
                <h3 style={{ fontSize: '15.5px', fontWeight: '700', color: 'var(--ink)' }}>{p.title}</h3>
                <span style={{ flexShrink: 0, fontSize: '10.5px', background: 'var(--primary-soft)', color: 'var(--primary)', padding: '2px 8px', borderRadius: '5px', textTransform: 'uppercase', fontWeight: '700' }}>
                  {p.possession_status || 'Active'}
                </span>
              </div>
              <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <MapPin size={14} /> {p.location}, {p.city}
              </p>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: 'var(--text-main)', background: 'var(--surface)', border: '1px solid var(--border)', padding: '10px', borderRadius: '10px', marginBottom: '12px' }}>
                <div>
                  <span style={{ color: 'var(--text-faint)', fontSize: '11px', display: 'block' }}>Type</span>
                  <strong>{p.bhk_type} Flat</strong>
                </div>
                <div>
                  <span style={{ color: 'var(--text-faint)', fontSize: '11px', display: 'block' }}>Area</span>
                  <strong>{p.sqft ? `${p.sqft} sqft` : '—'}</strong>
                </div>
                <div>
                  <span style={{ color: 'var(--text-faint)', fontSize: '11px', display: 'block' }}>Price</span>
                  <strong style={{ color: 'var(--success)' }}>₹{(p.price / 10000000).toFixed(2)} Cr</strong>
                </div>
              </div>
              {Array.isArray(p.amenities) && p.amenities.length > 0 && (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                  {p.amenities.slice(0, 4).map((a: string, idx: number) => (
                    <span key={idx} style={{ fontSize: '11px', background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text-muted)', padding: '2px 7px', borderRadius: '5px' }}>{a}</span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
