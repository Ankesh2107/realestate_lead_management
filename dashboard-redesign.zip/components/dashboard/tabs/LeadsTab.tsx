import React from 'react';
import { RefreshCw, Users } from 'lucide-react';
import { iconBtnStyle, panelStyle, statusBadgeStyle, tableStyle, tempBadgeStyle } from '@/lib/dashboard/styles';
import { Lead } from '@/types/dashboard';

const th: React.CSSProperties = {
  textAlign: 'left',
  fontSize: '11px',
  fontWeight: 700,
  color: 'var(--text-faint)',
  textTransform: 'uppercase',
  letterSpacing: '0.03em',
  padding: '0 12px 10px 12px',
  borderBottom: '1px solid var(--border)',
};

const td: React.CSSProperties = {
  padding: '13px 12px',
  borderBottom: '1px solid var(--border-soft)',
  color: 'var(--text-main)',
};

export function LeadsTab({
  leads,
  loadingLeads,
  fetchLeads,
}: {
  leads: Lead[];
  loadingLeads: boolean;
  fetchLeads: () => void;
}) {
  return (
    <div style={panelStyle}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: '700', color: 'var(--ink)' }}>Leads Directory</h2>
        <button onClick={fetchLeads} style={iconBtnStyle}><RefreshCw size={14} /> Refresh</button>
      </div>
      {loadingLeads ? (
        <p style={{ color: 'var(--text-muted)', fontSize: '13px' }}>Loading leads...</p>
      ) : leads.length === 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', padding: '50px 0', color: 'var(--text-faint)' }}>
          <Users size={28} />
          <p style={{ fontSize: '13px' }}>No leads yet.</p>
        </div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={tableStyle}>
            <thead>
              <tr>
                <th style={th}>Name / ID</th><th style={th}>Channel</th><th style={th}>Intent</th><th style={th}>Budget</th>
                <th style={th}>Locations</th><th style={th}>Status</th><th style={th}>Temp</th><th style={th}>Score</th><th style={th}>Last Active</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((l) => (
                <tr key={l.id}>
                  <td style={{ ...td, fontWeight: 600 }}>{l.name || l.external_user_id}</td>
                  <td style={{ ...td, textTransform: 'capitalize' }}>{l.channel}</td>
                  <td style={td}>{l.intent || '—'}</td>
                  <td style={td}>{l.budget_max ? `₹${(l.budget_max / 100000).toFixed(1)}L` : '—'}</td>
                  <td style={td}>{(l.preferred_locations || []).join(', ') || '—'}</td>
                  <td style={td}><span style={statusBadgeStyle(l.status)}>{l.status}</span></td>
                  <td style={td}><span style={tempBadgeStyle(l.temperature)}>{l.temperature}</span></td>
                  <td style={{ ...td, fontWeight: 700 }}>{l.lead_score ?? 0}</td>
                  <td style={{ ...td, color: 'var(--text-faint)', fontSize: '12px' }}>{new Date(l.updated_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
