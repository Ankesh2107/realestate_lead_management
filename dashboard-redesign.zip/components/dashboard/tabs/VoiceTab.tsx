import React from 'react';
import { Clock, Info, Loader2, Mic, PhoneCall, PhoneOff, RefreshCw, Send, Sliders, Sparkles, Volume2 } from 'lucide-react';
import { QuickVoiceChip } from '@/components/dashboard/ui/QuickVoiceChip';
import { StatusPill } from '@/components/dashboard/ui/StatusPill';
import { iconBtnStyle, panelStyle } from '@/lib/dashboard/styles';
import { useVoiceCall } from '@/hooks/useVoiceCall';

const LANGUAGE_OPTIONS = [
  ['hi-IN', 'Hindi (हिन्दी) 🇮🇳'],
  ['en-IN', 'English (Indian) 🇮🇳'],
] as const;

const GENDER_FILTERS = ['all', 'female', 'male'] as const;

export function VoiceTab({ voice }: { voice: ReturnType<typeof useVoiceCall> }) {
  const {
    voiceStatus,
    voiceLang,
    voiceSpeaker,
    voicePace,
    voiceGenderFilter,
    setVoiceGenderFilter,
    voiceTranscript,
    setVoiceTranscript,
    callDuration,
    audioLevel,
    interimText,
    voiceInput,
    setVoiceInput,
    noticeMsg,
    transcriptBottomRef,
    filteredVoices,
    startCall,
    endCall,
    processTurn,
    handleSendVoiceInput,
    formatDuration,
    selectLanguage,
    selectSpeaker,
    updatePace,
  } = voice;

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '440px 1fr', gap: '20px', alignItems: 'start' }}>
      {/* Call Control Console */}
      <div style={{ ...panelStyle, textAlign: 'center', padding: '28px 24px' }}>
        {/* AI Avatar */}
        <div style={{ position: 'relative', width: '100px', height: '100px', margin: '0 auto 16px' }}>
          <div style={{
            width: '100px', height: '100px', borderRadius: '50%',
            background: 'linear-gradient(135deg, #2f6fed, #7c5cff)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: voiceStatus === 'speaking'
              ? '0 0 0 10px rgba(47,111,237,0.16), 0 0 0 20px rgba(47,111,237,0.08)'
              : voiceStatus === 'listening'
              ? '0 0 0 10px rgba(22,163,74,0.16), 0 0 0 20px rgba(22,163,74,0.08)'
              : 'none',
            transition: 'box-shadow 0.4s ease',
          }}>
            <Sparkles size={44} color="#fff" />
          </div>
          {/* Status Dot */}
          <div style={{
            position: 'absolute', bottom: 4, right: 4,
            width: 18, height: 18, borderRadius: '50%',
            background: voiceStatus === 'idle' || voiceStatus === 'ended' ? '#a7a495'
              : voiceStatus === 'listening' ? 'var(--success)'
              : voiceStatus === 'speaking' ? 'var(--primary)'
              : 'var(--warning)',
            border: '3px solid var(--surface)',
            transition: 'background 0.3s',
          }} />
        </div>

        <h2 style={{ fontSize: '20px', fontWeight: '700', color: 'var(--ink)', marginBottom: '4px' }}>Realty AI Voice Agent</h2>
        <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginBottom: '16px' }}>
          Sarvam AI Bulbul v3 (TTS) + Gemini Sales Intelligence
        </p>

        {/* Call duration */}
        {(voiceStatus !== 'idle' && voiceStatus !== 'ended') && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', fontSize: '24px', fontWeight: '700', color: 'var(--success)', marginBottom: '16px', fontVariantNumeric: 'tabular-nums' }}>
            <Clock size={18} /> {formatDuration(callDuration)}
          </div>
        )}

        {/* Status Pill */}
        <div style={{ marginBottom: '16px' }}>
          <StatusPill status={voiceStatus} />
        </div>

        {/* Mic level bar when listening */}
        {voiceStatus === 'listening' && (
          <div style={{ marginBottom: '16px' }}>
            <div style={{ height: '8px', background: 'var(--border)', borderRadius: '4px', overflow: 'hidden' }}>
              <div style={{ height: '100%', width: `${Math.max(10, audioLevel)}%`, background: 'linear-gradient(90deg, var(--success), var(--primary))', borderRadius: '4px', transition: 'width 0.05s ease' }} />
            </div>
            <p style={{ fontSize: '12px', color: 'var(--success)', marginTop: '6px', fontWeight: '500' }}>
              🎙️ Listening live... speak your property query
            </p>
          </div>
        )}

        {/* Notice / Feedback banner */}
        {noticeMsg && (
          <div style={{ marginBottom: '16px', padding: '10px 12px', borderRadius: '8px', background: 'var(--warning-soft)', border: '1px solid rgba(217,138,31,0.25)', color: 'var(--warning)', fontSize: '12px', textAlign: 'left', display: 'flex', gap: '8px', alignItems: 'center' }}>
            <Info size={16} style={{ flexShrink: 0 }} />
            <span>{noticeMsg}</span>
          </div>
        )}

        {/* Language & Voice Selector */}
        {(voiceStatus === 'idle' || voiceStatus === 'ended') && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginBottom: '24px', textAlign: 'left', background: 'var(--surface-alt)', padding: '16px', borderRadius: '10px', border: '1px solid var(--border)' }}>
            <div>
              <label style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '6px', display: 'block', fontWeight: '600' }}>
                🌐 Language Accent
              </label>
              <div style={{ display: 'flex', gap: '8px' }}>
                {LANGUAGE_OPTIONS.map(([code, label]) => (
                  <button key={code} onClick={() => selectLanguage(code)} style={{ flex: 1, padding: '8px 12px', borderRadius: '8px', border: `1px solid ${voiceLang === code ? 'var(--primary)' : 'var(--border)'}`, background: voiceLang === code ? 'var(--primary-soft)' : 'var(--surface)', color: voiceLang === code ? 'var(--primary)' : 'var(--text-muted)', fontSize: '12px', fontWeight: '600', cursor: 'pointer' }}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                <label style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: '600' }}>
                  🎙️ Select AI Voice ({filteredVoices.length} options)
                </label>
                <div style={{ display: 'flex', gap: '4px' }}>
                  {GENDER_FILTERS.map((g) => (
                    <button key={g} onClick={() => setVoiceGenderFilter(g)} style={{ padding: '2px 8px', borderRadius: '4px', border: 'none', background: voiceGenderFilter === g ? 'var(--ink)' : 'var(--border)', color: voiceGenderFilter === g ? '#fff' : 'var(--text-muted)', fontSize: '10px', textTransform: 'capitalize', cursor: 'pointer' }}>
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', maxHeight: '200px', overflowY: 'auto', paddingRight: '4px' }}>
                {filteredVoices.map((v) => (
                  <button key={v.id} onClick={() => selectSpeaker(v.id)} style={{ textAlign: 'left', padding: '8px 10px', borderRadius: '8px', border: `1px solid ${voiceSpeaker === v.id ? 'var(--violet)' : 'var(--border)'}`, background: voiceSpeaker === v.id ? 'var(--violet-soft)' : 'var(--surface)', color: voiceSpeaker === v.id ? 'var(--violet)' : 'var(--text-main)', cursor: 'pointer' }}>
                    <div style={{ fontSize: '12px', fontWeight: '600' }}>{v.name}</div>
                    <div style={{ fontSize: '10px', color: 'var(--text-muted)', marginTop: '2px' }}>{v.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Speech Pace Slider */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                <label style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Sliders size={12} /> Speech Cadence Speed
                </label>
                <span style={{ fontSize: '11px', color: 'var(--primary)', fontWeight: '700' }}>{voicePace.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.85"
                max="1.15"
                step="0.05"
                value={voicePace}
                onChange={(e) => updatePace(parseFloat(e.target.value))}
                style={{ width: '100%', accentColor: 'var(--primary)', cursor: 'pointer' }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px', color: 'var(--text-faint)', marginTop: '2px' }}>
                <span>Relaxed (0.85x)</span>
                <span>Conversational (1.0x)</span>
                <span>Fast (1.15x)</span>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', marginBottom: '20px' }}>
          {voiceStatus === 'idle' || voiceStatus === 'ended' ? (
            <button
              id="start-call-btn"
              onClick={startCall}
              style={{ padding: '14px 36px', borderRadius: '50px', border: 'none', background: 'linear-gradient(135deg, #16a34a, #0f8a3d)', color: '#fff', fontWeight: '700', fontSize: '16px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '10px', boxShadow: '0 6px 20px rgba(22,163,74,0.28)' }}>
              <PhoneCall size={20} /> Start Voice Call
            </button>
          ) : (
            <>
              {voiceStatus === 'listening' && (
                <button
                  onClick={() => processTurn(interimText)}
                  style={{ padding: '12px 20px', borderRadius: '50px', background: 'var(--primary)', color: '#fff', fontWeight: '600', fontSize: '13px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', border: 'none', boxShadow: '0 6px 16px rgba(47,111,237,0.28)' }}>
                  <Mic size={16} /> Send Speech
                </button>
              )}
              <button
                id="end-call-btn"
                onClick={endCall}
                style={{ padding: '12px 24px', borderRadius: '50px', border: 'none', background: 'linear-gradient(135deg, #e0433a, #c9342b)', color: '#fff', fontWeight: '700', fontSize: '14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', boxShadow: '0 6px 18px rgba(224,67,58,0.28)' }}>
                <PhoneOff size={18} /> End Call
              </button>
            </>
          )}
        </div>

        {/* Interactive Speech Input & Quick Chips during call */}
        {(voiceStatus === 'listening' || voiceStatus === 'speaking' || voiceStatus === 'processing') && (
          <div style={{ marginTop: '16px', borderTop: '1px solid var(--border)', paddingTop: '16px', textAlign: 'left' }}>
            <label style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '8px', display: 'block' }}>
              💬 Speak into mic or type a test message:
            </label>

            <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
              <input
                type="text"
                placeholder="e.g. 3BHK flat in Noida under 1.5 Cr..."
                value={voiceInput}
                onChange={(e) => setVoiceInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendVoiceInput()}
                style={{ flex: 1, padding: '10px 14px', borderRadius: '8px', border: '1px solid var(--border)', background: 'var(--surface-alt)', color: 'var(--ink)', fontSize: '13px', outline: 'none' }}
              />
              <button
                onClick={() => handleSendVoiceInput()}
                style={{ padding: '10px 16px', borderRadius: '8px', border: 'none', background: 'var(--primary)', color: '#fff', fontWeight: '600', fontSize: '13px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <Send size={14} /> Send
              </button>
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              <QuickVoiceChip text="Noida 3BHK under 1.5 Cr?" onClick={(t) => handleSendVoiceInput(t)} />
              <QuickVoiceChip text="Book Saturday site visit" onClick={(t) => handleSendVoiceInput(t)} />
              <QuickVoiceChip text="Connect with sales manager" onClick={(t) => handleSendVoiceInput(t)} />
            </div>
          </div>
        )}
      </div>

      {/* Live Transcript & Real-Time Voice Wave Panel */}
      <div style={panelStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', borderBottom: '1px solid var(--border)', paddingBottom: '12px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '600', color: 'var(--ink)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Volume2 size={18} style={{ color: 'var(--violet)' }} /> Live Call Transcript
          </h3>
          {voiceTranscript.length > 0 && (
            <button onClick={() => setVoiceTranscript([])} style={iconBtnStyle}>
              <RefreshCw size={12} /> Clear Log
            </button>
          )}
        </div>

        <div style={{ height: '560px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '14px', paddingRight: '4px' }}>
          {voiceTranscript.length === 0 && !interimText && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: '12px' }}>
              <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'var(--violet-soft)', border: '1px solid rgba(124,92,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Mic size={28} color="var(--violet)" />
              </div>
              <p style={{ color: 'var(--text-muted)', fontSize: '14px', textAlign: 'center', lineHeight: '1.6' }}>
                Click <strong>Start Voice Call</strong> to speak live with Realty AI.<br />
                Select from 14 distinct male/female Sarvam Bulbul v3 voices!
              </p>
            </div>
          )}

          {/* Speech Log */}
          {voiceTranscript.map((t, i) => (
            <div key={i} style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
              <div style={{
                flexShrink: 0, width: '36px', height: '36px', borderRadius: '50%',
                background: t.speaker === 'You' ? 'var(--primary-soft)' : 'var(--violet-soft)',
                border: `1px solid ${t.speaker === 'You' ? 'rgba(47,111,237,0.3)' : 'rgba(124,92,255,0.3)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: '700',
                color: t.speaker === 'You' ? 'var(--primary)' : 'var(--violet)',
              }}>
                {t.speaker === 'You' ? 'U' : 'AI'}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '4px' }}>
                  <span style={{ fontSize: '13px', fontWeight: '600', color: t.speaker === 'You' ? 'var(--primary)' : 'var(--violet)' }}>{t.speaker}</span>
                  <span style={{ fontSize: '11px', color: 'var(--text-faint)' }}>{t.time}</span>
                </div>
                <div style={{ fontSize: '14px', color: 'var(--text-main)', lineHeight: '1.6', background: t.speaker === 'Realty AI' ? 'var(--surface-alt)' : '#fbfbf9', padding: '10px 14px', borderRadius: '10px', border: '1px solid var(--border-soft)' }}>
                  {t.text}
                </div>
              </div>
            </div>
          ))}

          {/* Live interim text preview as user speaks */}
          {interimText && (
            <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start', opacity: 0.85 }}>
              <div style={{ flexShrink: 0, width: '36px', height: '36px', borderRadius: '50%', background: 'var(--success-soft)', border: '1px solid rgba(22,163,74,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: '700', color: 'var(--success)' }}>
                U
              </div>
              <div style={{ flex: 1 }}>
                <span style={{ fontSize: '12px', color: 'var(--success)', fontStyle: 'italic', marginBottom: '2px', display: 'block' }}>Speaking live...</span>
                <div style={{ fontSize: '14px', color: 'var(--success)', fontStyle: 'italic', background: 'var(--success-soft)', padding: '10px 14px', borderRadius: '10px', border: '1px dashed rgba(22,163,74,0.3)' }}>
                  "{interimText}"
                </div>
              </div>
            </div>
          )}

          {/* Processing indicator */}
          {voiceStatus === 'processing' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: 'var(--primary)', fontSize: '13px', fontStyle: 'italic', padding: '10px 14px', background: 'var(--primary-soft)', borderRadius: '8px', border: '1px solid rgba(47,111,237,0.2)' }}>
              <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> Processing query with Sarvam AI + Gemini...
            </div>
          )}

          <div ref={transcriptBottomRef} />
        </div>
      </div>
    </div>
  );
}
