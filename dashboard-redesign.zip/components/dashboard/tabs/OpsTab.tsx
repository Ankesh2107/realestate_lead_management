import React from 'react';
import { CalendarClock, RefreshCw, UserPlus } from 'lucide-react';
import { iconBtnStyle, panelStyle } from '@/lib/dashboard/styles';
import { Escalation, SiteVisit } from '@/types/dashboard';

export function OpsTab({
  siteVisits,
  escalations,
  loadingOps,
  fetchOps,
}: {
  siteVisits: SiteVisit[];
  escalations: Escalation[];
  loadingOps: boolean;
  fetchOps: () => void;
}) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
      <div style={panelStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
          <h2 style={{ fontSize: '16px', fontWeight: '700', color: 'var(--ink)' }}>Scheduled Site Visits</h2>
          <button onClick={fetchOps} style={iconBtnStyle}><RefreshCw size={14} /> Refresh</button>
        </div>
        {loadingOps ? (
          <p style={{ color: 'var(--text-muted)', fontSize: '13px' }}>Loading...</p>
        ) : siteVisits.length === 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', padding: '40px 0', color: 'var(--text-faint)' }}>
            <CalendarClock size={26} />
            <p style={{ fontSize: '13px' }}>No site visits recorded yet.</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {siteVisits.map((v) => (
              <div key={v.id} style={{ padding: '12px 14px', background: 'var(--surface-alt)', border: '1px solid var(--border)', borderRadius: '12px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: '600', color: 'var(--ink)' }}>
                  <span>Visit #{v.id.slice(0, 6)}</span>
                  <span style={{ color: 'var(--success)' }}>{v.status || 'Scheduled'}</span>
                </div>
                <p style={{ fontSize: '12.5px', color: 'var(--text-muted)', marginTop: '4px' }}>
                  Date: {new Date(v.scheduled_time || v.visit_date).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={panelStyle}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
          <h2 style={{ fontSize: '16px', fontWeight: '700', color: 'var(--ink)' }}>Human Escalations &amp; Support</h2>
          <button onClick={fetchOps} style={iconBtnStyle}><RefreshCw size={14} /> Refresh</button>
        </div>
        {loadingOps ? (
          <p style={{ color: 'var(--text-muted)', fontSize: '13px' }}>Loading...</p>
        ) : escalations.length === 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', padding: '40px 0', color: 'var(--text-faint)' }}>
            <UserPlus size={26} />
            <p style={{ fontSize: '13px' }}>No escalated leads pending.</p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {escalations.map((e) => (
              <div key={e.id} style={{ padding: '12px 14px', background: 'var(--surface-alt)', border: '1px solid var(--border)', borderRadius: '12px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: '600', color: 'var(--ink)' }}>
                  <span>Escalation #{e.id.slice(0, 6)}</span>
                  <span style={{ color: 'var(--danger)' }}>{e.status || 'Pending'}</span>
                </div>
                <p style={{ fontSize: '12.5px', color: 'var(--text-muted)', marginTop: '4px' }}>
                  Reason: {e.reason || 'Human agent requested by customer'}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
