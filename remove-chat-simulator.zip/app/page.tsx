'use client';

import React, { useState } from 'react';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { VoiceTab } from '@/components/dashboard/tabs/VoiceTab';
import { LeadsTab } from '@/components/dashboard/tabs/LeadsTab';
import { PropertiesTab } from '@/components/dashboard/tabs/PropertiesTab';
import { OpsTab } from '@/components/dashboard/tabs/OpsTab';
import { useHealthCheck } from '@/hooks/useHealthCheck';
import { useDashboardLists } from '@/hooks/useDashboardLists';
import { useVoiceCall } from '@/hooks/useVoiceCall';
import { ActiveTab } from '@/types/dashboard';

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('voice');

  const { health } = useHealthCheck();
  const voice = useVoiceCall();
  const {
    leads, loadingLeads, fetchLeads,
    properties, loadingProperties, fetchProperties,
    siteVisits, escalations, loadingOps, fetchOps,
  } = useDashboardLists(activeTab);

  return (
    <div style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto' }}>
      <DashboardHeader health={health} activeTab={activeTab} setActiveTab={setActiveTab} />

      {activeTab === 'voice' && <VoiceTab voice={voice} />}
      {activeTab === 'leads' && <LeadsTab leads={leads} loadingLeads={loadingLeads} fetchLeads={fetchLeads} />}
      {activeTab === 'properties' && (
        <PropertiesTab properties={properties} loadingProperties={loadingProperties} fetchProperties={fetchProperties} />
      )}
      {activeTab === 'ops' && (
        <OpsTab siteVisits={siteVisits} escalations={escalations} loadingOps={loadingOps} fetchOps={fetchOps} />
      )}
    </div>
  );
}
