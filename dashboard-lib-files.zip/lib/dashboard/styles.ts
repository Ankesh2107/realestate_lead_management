import React from 'react';

export const panelStyle: React.CSSProperties = {
  background: '#131b2e',
  borderRadius: '12px',
  border: '1px solid #232f48',
  padding: '20px',
};

export const iconBtnStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: '4px',
  padding: '6px 10px',
  borderRadius: '6px',
  border: '1px solid #232f48',
  background: '#0b0f19',
  color: '#9ca3af',
  fontSize: '12px',
  cursor: 'pointer',
};

export const tableStyle: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: '13px',
  color: '#e5e7eb',
};

export function healthBadgeStyle(ok: boolean): React.CSSProperties {
  return {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    padding: '6px 12px',
    borderRadius: '20px',
    fontSize: '12px',
    fontWeight: '600',
    background: ok ? 'rgba(16,185,129,0.15)' : 'rgba(239,68,68,0.15)',
    color: ok ? '#34d399' : '#f87171',
    border: `1px solid ${ok ? 'rgba(16,185,129,0.3)' : 'rgba(239,68,68,0.3)'}`,
  };
}

export function statusBadgeStyle(status: string): React.CSSProperties {
  const isHot = status === 'qualified' || status === 'visit_scheduled';
  return {
    padding: '2px 8px',
    borderRadius: '4px',
    fontSize: '11px',
    fontWeight: '600',
    textTransform: 'uppercase',
    background: isHot ? 'rgba(16,185,129,0.15)' : 'rgba(107,114,128,0.15)',
    color: isHot ? '#34d399' : '#9ca3af',
  };
}

export function tempBadgeStyle(temp: string): React.CSSProperties {
  const isHot = temp === 'HOT';
  const isWarm = temp === 'WARM';
  return {
    padding: '2px 8px',
    borderRadius: '4px',
    fontSize: '11px',
    fontWeight: '600',
    background: isHot ? 'rgba(239,68,68,0.15)' : isWarm ? 'rgba(245,158,11,0.15)' : 'rgba(59,130,246,0.15)',
    color: isHot ? '#f87171' : isWarm ? '#fbbf24' : '#60a5fa',
  };
}
